import json
from sshtunnel import SSHTunnelForwarder
import redis
import boto3

state_machine_definition = {
  "Comment": "Lambda execution workflow",
  "StartAt": "Authentification",
  "States": {
    "Authentification": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:auth",
      "Parameters": {
        "waiting_queue.$": "$$.Execution.Input.waiting_queue",
        "password_queue.$": "$$.Execution.Input.password_queue",
        "username.$": "$$.Execution.Input.username",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "password.$": "$$.Execution.Input.password",
        "path_key.$": "$$.Execution.Input.path_key"
      },
      "Next": "CheckHeartbeat"
    },
    "CheckHeartbeat": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:check_heartbeat",
      "Parameters": {
        "username.$": "$$.Execution.Input.username",
        "path_key.$": "$$.Execution.Input.path_key",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "password.$": "$$.Execution.Input.password",
        "epoch.$": "$$.Execution.Input.epoch"
      },
      "Next": "ComputeGradients"
    },
    "ComputeGradients": {
      "Type": "Parallel",
      "Branches": [
        {
          "StartAt": "Batch1",
          "States": {
            "Batch1": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[0]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch2",
          "States": {
            "Batch2": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[1]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch3",
          "States": {
            "Batch3": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[2]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch4",
          "States": {
            "Batch4": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[3]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch5",
          "States": {
            "Batch5": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[4]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch6",
          "States": {
            "Batch6": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[5]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch7",
          "States": {
            "Batch7": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[6]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch8",
          "States": {
            "Batch8": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[7]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch9",
          "States": {
            "Batch9": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[8]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch10",
          "States": {
            "Batch10": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[9]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch11",
          "States": {
            "Batch11": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[10]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch12",
          "States": {
            "Batch12": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[11]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch13",
          "States": {
            "Batch13": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[12]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch14",
          "States": {
            "Batch14": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch15",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch16",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch17",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch18",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch19",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[13]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        },
        {
          "StartAt": "Batch20",
          "States": {
            "Batch15": {
              "Type": "Task",
              "Resource": "arn:aws:lambda:us-east-1:736943246631:function:compute_gradients",
              "Parameters": {
                "rank.$": "$$.Execution.Input.rank",
                "size.$": "$$.Execution.Input.size",
                "batch_rank.$": "$$.Execution.Input.batch_rank[14]",
                "ec2_ip.$": "$$.Execution.Input.ec2_ip",
                "port.$": "$$.Execution.Input.port",
                "dataset.$": "$$.Execution.Input.dataset",
                "model_str.$": "$$.Execution.Input.model_str",
                "optimiser.$": "$$.Execution.Input.optimiser",
                "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
                "loss.$": "$$.Execution.Input.loss",
                "username.$": "$$.Execution.Input.username",
                "password.$": "$$.Execution.Input.password",
                "path_key.$": "$$.Execution.Input.path_key",
                "num_batches.$": "$$.Execution.Input.num_batches",
                "num_peers.$": "$$.Execution.Input.num_peers",
                "epoch.$": "$$.Execution.Input.epoch",
                "attack.$": "$$.Execution.Input.attack"
              },
              "End": True
            }
          }
        }
      ],
      "Next": "AverageGradients"
    },
    "AverageGradients": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:Trigger_Average_Gradient_sync",
      "Parameters": {
        "rank.$": "$$.Execution.Input.rank",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "username.$": "$$.Execution.Input.username",
        "password.$": "$$.Execution.Input.password",
        "path_key.$": "$$.Execution.Input.path_key",
        "num_batches.$": "$$.Execution.Input.num_batches",
        "num_peers.$": "$$.Execution.Input.num_peers",
        "epoch.$": "$$.Execution.Input.epoch",
        "attack.$": "$$.Execution.Input.attack"
      },
      "Next": "Aggregation"
    },
    "Aggregation": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:aggregation",
      "Parameters": {
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "password.$": "$$.Execution.Input.password",
        "username.$": "$$.Execution.Input.username",
        "path_key.$": "$$.Execution.Input.path_key",
        "port.$": "$$.Execution.Input.port",
        "epoch.$": "$$.Execution.Input.epoch"
      },
      "Next": "Update"
    },
    "Update": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:Trigger_update_model",
      "Parameters": {
        "grad_key.$": "$$.Execution.Input.grad_key",
        "param_key.$": "$$.Execution.Input.param_key",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "password.$": "$$.Execution.Input.password",
        "username.$": "$$.Execution.Input.username",
        "path_key.$": "$$.Execution.Input.path_key",
        "epoch.$": "$$.Execution.Input.epoch"
      },
      "Next": "CheckConvergence"
    },
    "CheckConvergence": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:check-convergence",
      "Parameters": {
        "waiting_queue.$": "$$.Execution.Input.waiting_queue",
        "password_queue.$": "$$.Execution.Input.password_queue",
        "username.$": "$$.Execution.Input.username",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "password.$": "$$.Execution.Input.password",
        "path_key.$": "$$.Execution.Input.path_key",
        "rank.$": "$$.Execution.Input.rank",
        "size.$": "$$.Execution.Input.size",
        "batch_rank.$": "$$.Execution.Input.batch_rank",
        "dataset.$": "$$.Execution.Input.dataset",
        "model_str.$": "$$.Execution.Input.model_str",
        "optimiser.$": "$$.Execution.Input.optimiser",
        "optimiser_lr.$": "$$.Execution.Input.optimiser_lr",
        "loss.$": "$$.Execution.Input.loss",
        "num_batches.$": "$$.Execution.Input.num_batches",
        "num_peers.$": "$$.Execution.Input.num_peers",
        "grad_key.$": "$$.Execution.Input.grad_key",
        "param_key.$": "$$.Execution.Input.param_key",
        "bucket.$": "$$.Execution.Input.bucket",
        "batch_size.$": "$$.Execution.Input.batch_size",
        "epoch.$": "$$.Execution.Input.epoch",
        "attack.$": "$$.Execution.Input.attack"
      },
      "Next": "trigger_next"
      
      
    },
    "trigger_next": {
      "Type": "Task",
      "Resource": "arn:aws:lambda:us-east-1:736943246631:function:Update_Trigger_Next_epoch",
      "Parameters": {
        "grad_key.$": "$$.Execution.Input.grad_key",
        "param_key.$": "$$.Execution.Input.param_key",
        "ec2_ip.$": "$$.Execution.Input.ec2_ip",
        "port.$": "$$.Execution.Input.port",
        "password.$": "$$.Execution.Input.password",
        "username.$": "$$.Execution.Input.username",
        "path_key.$": "$$.Execution.Input.path_key",
        "epoch.$": "$$.Execution.Input.epoch"
      },
    "End": True
    }
  }
}

    

def create_and_deploy(state_machine_definition):
    # Client for Step Functions
    sfn_client = boto3.client('stepfunctions')
    
    # Load your state machine definition
    # state_machine_def = json.loads(state_machine_definition)
    
    # Specify IAM role
    role_arn = 'arn:aws:iam::736943246631:role/service-role/StepFunctions-test_workflow-role-fdba2ce3'
    
    # Create state machine
    response = sfn_client.create_state_machine(
        name='new_epoch',
        definition=json.dumps(state_machine_definition),
        roleArn=role_arn,
    )
    
    
    return response
    
def read_inactive_peers(host, port, password, SSH_USERNAME, PRIVATE_KEY_PATH,epoch):
    key = f"gradients_" + str(epoch)
    json_data = {}
    REDIS_HOST = 'localhost'
    for i in range(4):
        with SSHTunnelForwarder(
        (host, 22),
        ssh_username=SSH_USERNAME,
        ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
        remote_bind_address=(REDIS_HOST, port)
        ) as tunnel:
            redis_client  = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= password) 
            private_key = redis_client.get('private_key')
    
def lambda_handler(event, context):
    input_data = event
    host = input_data['ec2_ip']
    port = input_data['port']
    password = input_data['password']
    SSH_USERNAME = input_data['username']
    PRIVATE_KEY_PATH = input_data['path_key']
    epoch = input_data['epoch']
    num_parallel = 20

    read_inactive_peers(host, port, password,SSH_USERNAME,PRIVATE_KEY_PATH,epoch )
    
    
    # new_aws_step_function = create_and_deploy (state_machine_definition)
    
    
    
    
    
    
    
