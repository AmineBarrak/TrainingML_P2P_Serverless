from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric import rsa
import sys
import redis
import json
import dill as pickle
from cryptography.hazmat.backends import default_backend
import argparse
from cryptography.fernet import Fernet



def encrypt_data(password, publicKey):
    if type(password) is not bytes:
        password = password.encode()
    # Encrypt the password using the public key
    if type(publicKey) is bytes:
        publicKey = serialization.load_pem_public_key(
        publicKey,
        backend=default_backend()
    )
    encrypted_password = publicKey.encrypt(
        password,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_password


"""def encrypt_data_final(password, public_key_str):
    # Encrypt the password using the public key
    public_key = serialization.load_pem_public_key(
        public_key_str,
        backend=default_backend()
    )
    encrypted_password = public_key.encrypt(
        password,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_password"""
def decrypt_data(password, private_key_bytes):
    private_key = serialization.load_pem_private_key(
        private_key_bytes,
        password=None
    )
    decrypted_data = private_key.decrypt(
        password,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_data

def generate_signature(private_key_str):
    private_key = serialization.load_pem_private_key(
        private_key_str,
        password=None,
    )
    signature = private_key.sign(
        b"OK",
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature

def receive_from_other_peers_now(channel, queue_name):
    channel.queue_declare(queue=queue_name)
    # Retrieve a single message from the queue
    method_frame, properties, body = channel.basic_get(queue=queue_name, auto_ack=True)
    message = pickle.loads(body)
    return message

def receive_password(channel, ip, number_new_accepted_peers):
    # initialize a status object to check for received messages

    print(type(number_new_accepted_peers))
    print(number_new_accepted_peers)
    received_passwords = []
    print("start receiving") 
    queue_name = "password"+str(ip)
    channel.queue_declare(queue=queue_name)
    message_count = 0
    def callback(ch, method, properties, body):
        nonlocal message_count
        nonlocal received_passwords
        message = pickle.loads(body)
        if verify_signature(message):
            message_count += 1
            received_passwords.append(message)
        
        if message_count == number_new_accepted_peers:

            ch.stop_consuming()

    channel.basic_consume(queue=queue_name, on_message_callback=callback, auto_ack=True)
    print("Waiting for peers passwords...")
    channel.start_consuming()
    print("Received all peers passwords.")
    return received_passwords

"""def verify_signature_redis(message):
    
    public_key_str = message['public_key']
    # Convert the string to a public key object
    public_key = serialization.load_pem_public_key(
        public_key_str,
        backend=default_backend()
    )

    # print(message['signature'].decode())
    # Print the public key object
    try:
        public_key.verify(
            message['signature'],
            b"OK",
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        print("Signature verification successful")
        return message
    except:
        print("Signature verification failed")
        return False"""

def verify_signature(message):
    
    public_key_str = message['public_key']
    if type(public_key_str) is str:
        public_key_str=public_key_str.encode()

    # Convert the string to a public key object
    public_key = serialization.load_pem_public_key(
        public_key_str,
        backend=default_backend()
    )

    # print(message['signature'].decode())
    # Print the public key object
    try:
        public_key.verify(
            message['signature'],
            b"OK",
            padding.PSS(
                mgf=padding.MGF1(hashes.SHA256()),
                salt_length=padding.PSS.MAX_LENGTH
            ),
            hashes.SHA256()
        )
        print("Signature verification successful")
        return message
    except:
        print("Signature verification failed")
        return False


def lambda_handler(event, context):
    input_data = event
    
    # Perform a calculation using the input data
    SSH_USERNAME = input_data['username']
    PRIVATE_KEY_PATH = input_data['path_key']
    my_ip = input_data['ip_ec2']
    other_sqs_urls = input_data['ips_sns']
    # ports = input_data['ports']
    my_port = int(input_data['my_port'])
    my_password = input_data['password']
    sqs_password = input_data['sns_password']
    number_peer = input_data['number_peer']


    sqs = session.client('sqs')

    # Create a queue for messages
    response = sqs.create_queue(QueueName="waiting" + my_ip)
    queue_url = response['QueueUrl']

    # Redis setup
    r = redis.Redis(host='localhost', port=my_port, password=my_password)
    private_key = r.get('private_key')
    my_public_key = r.get('public_key')
    provided_passwords = 0
    deleted_count = r.delete('trusted_peers')

    # Receiving messages from SQS
    messages = sqs.receive_message(
        QueueUrl=queue_url,
        MaxNumberOfMessages=10  # Adjust based on expected traffic
    )

    # Processing each message
    for message in messages.get('Messages', []):
        message_body = json.loads(message['Body'])
        message_body = verify_signature(message_body)
        if message_body:
            data = {message_body['ip']: {'port': message_body['port'], 'public_key': message_body['public_key']}}
            if r.exists('trusted_peers'):
                if 'password' in message_body:
                    print("PASSWORD PROVIDED")
                    provided_passwords += 1
                    encrypted_password = encrypt_data(decrypt_data(message_body['password'], private_key), my_public_key).hex()
                    data[message_body['ip']].update({"password": encrypted_password})
                    print(data)
                existing_data_json = r.get('trusted_peers')
                existing_data = json.loads(existing_data_json)
                existing_data.update(data)
                updated_data_json = json.dumps(existing_data)
                print(updated_data_json)
                r.set('trusted_peers', updated_data_json)
            else:
                data_json = json.dumps(data)
                r.set('trusted_peers', data_json)

            # Send password to the new peer
            passowrd_encrypted = encrypt_data(my_password, serialization.load_pem_public_key(message_body['public_key'].encode('utf-8')))
            password_message = {'ip': my_ip, 'public_key': my_public_key, 'signature': generate_signature(private_key), 'password': passowrd_encrypted, 'port': my_port}
            password_bytes = pickle.dumps(password_message)
            response = sqs.create_queue(QueueName='password' + str(message_body['ip']))
            password_queue_url = response['QueueUrl']
            sqs.send_message(
                QueueUrl=password_queue_url,
                MessageBody=password_bytes
            )
            print("sent")

        # Delete the message from the queue after processing
        sqs.delete_message(
            QueueUrl=queue_url,
            ReceiptHandle=message['ReceiptHandle']
        )

    # Calculate new and existing peers
    number_new_accepted_peers = len(messages.get('Messages', [])) - provided_passwords
    print('=================')
    print(len(messages.get('Messages', [])))
    print(provided_passwords)
    print(number_new_accepted_peers)
    print('=================')

    if number_new_accepted_peers:
        passwords =  receive_password(channel,my_ip,number_new_accepted_peers)
        existing_data_json = r.get('trusted_peers')
        existing_data = json.loads(existing_data_json)
        for password in passwords:
            existing_data[password['ip']].update({'password': encrypt_data(decrypt_data(password['password'],private_key),my_public_key).hex()})
        updated_data_json = json.dumps(existing_data)
        r.set('trusted_peers', updated_data_json)
    if number_peer:

        passwords =  receive_password(channel,my_ip, int(number_peer))
        print(len(passwords))
        for password in passwords:
            data = {str(password['ip']):{
                'port' : password['port'],
                'public_key': password['public_key'].decode('utf-8'),
                'password' : encrypt_data(decrypt_data(password['password'],private_key),my_public_key).hex()
            }}

            if r.exists('trusted_peers'):
                existing_data_json = r.get('trusted_peers')
                existing_data = json.loads(existing_data_json)
                existing_data.update(data)
                print(existing_data)
                updated_data_json = json.dumps(existing_data)
                r.set('trusted_peers', updated_data_json)
            else:
                data_json = json.dumps(data)
                r.set('trusted_peers', data_json)

