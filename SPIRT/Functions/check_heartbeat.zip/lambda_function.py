import redis
import sys
import argparse
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend
import argparse
import json
from sshtunnel import SSHTunnelForwarder
from cryptography.fernet import Fernet



def decrypt_data(password, private_key_bytes):
    private_key = serialization.load_pem_private_key(
        private_key_bytes,
        password=None
    )
    decrypted_data = private_key.decrypt(
        password.encode('latin-1'),
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return decrypted_data
def check_heartbeat(host, port, password, SSH_USERNAME, PRIVATE_KEY_PATH,epoch):
    key = f"gradients_" + str(epoch)
    json_data = {}
    REDIS_HOST = 'localhost'
    for i in range(3):
        with SSHTunnelForwarder(
        (host, 22),
        ssh_username=SSH_USERNAME,
        ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
        remote_bind_address=(REDIS_HOST, port)
        ) as tunnel:
            redis_connection = redis.Redis(host= 'localhost', port=tunnel.local_bind_port, password= password)
            private_key = redis_connection.get('private_key')
            trusted_peers = redis_connection.get('trusted_peers')
            response = redis_connection.ping()
            try:
                    response = redis_connection.ping()
                    if response:
                        print("Redis is healthy and responsive.")
                    else:
                        print("Redis is not responding.")
            except redis.exceptions.ConnectionError:
                    print("Failed to connect to Redis.")
            redis_connection.delete(key)
        
    if trusted_peers:
        json_data = json.loads(trusted_peers)
        for key, value in json_data.items():
            with SSHTunnelForwarder(
            (key, 22),
            ssh_username=SSH_USERNAME,
            ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
            remote_bind_address=(REDIS_HOST, value['port'])
            ) as tunnel:
                r = redis.Redis(host= 'localhost', port=tunnel.local_bind_port, password=  (decrypt_data(value['password'],private_key)))
                response = r.ping()
                try:
                    response = r.ping()
                    if response:
                        print("Redis is healthy and responsive.")
                    else:
                        print("Redis is not responding.")
                except redis.exceptions.ConnectionError:
                    print("Failed to connect to Redis.")
def lambda_handler(event, context):
    input_data = event
    host = input_data['ec2_ip']
    port = input_data['port']
    password = input_data['password']
    SSH_USERNAME = input_data['username']
    PRIVATE_KEY_PATH = input_data['path_key']
    epoch = input_data['epoch']

    check_heartbeat(host, port, password,SSH_USERNAME,PRIVATE_KEY_PATH,epoch )
