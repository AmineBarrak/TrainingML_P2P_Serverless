import json
import pika
import ssl

import time


def wait_for_n_messages_or_timeout(channel, queue_name, n, timeout=500):
    start_time = time.time()

    print(f"Waiting for at least {n} messages in '{queue_name}' or timeout after {timeout} seconds.")

    while True:
        # Check the queue without consuming messages
        queue = channel.queue_declare(queue=queue_name, passive=True)
        message_count = queue.method.message_count

        if message_count >= n:
            print(f"Found {message_count} messages in the queue. Proceeding...")
            return True  # Return True if n messages are found

        # Check for timeout
        if (time.time() - start_time) > timeout:
            print("Timeout reached. Exiting.")
            return False  # Return False if timeout is reached
            
def send_message(channel, queue_name, message):
    # Ensure the queue exists
    #channel.queue_declare(queue=queue_name, durable=True)
    #sleep(1)

    # Convert the message to bytes
    message_bytes = message.encode('utf-8')

    # Publish the message to the queue
    channel.basic_publish(exchange='',
                          routing_key=queue_name,
                          body=message_bytes,
                          properties=pika.BasicProperties(
                             delivery_mode=2,  # make message persistent
                          ))
    print(f"Sent: {message}")
    
    
def lambda_handler(event, context):
    
    worker_index = event['worker_index']
    num_worker = event['num_workers']
    credentials = pika.PlainCredentials("*******", "**************")
    
    ssl_context = ssl.create_default_context(cafile='AmazonRootCA1.pem')
    ssl_context.check_hostname = False
    ssl_context.verify_mode = ssl.CERT_NONE

    # Set up connection parameters with the SSL context
    connection_parameters = pika.ConnectionParameters("b-0b3e161b-54da-47bc-b2ef-05692144f6a9.mq.us-east-1.amazonaws.com",
													virtual_host='/',
													credentials = credentials,
													ssl_options=pika.SSLOptions(ssl_context))
    connection = pika.BlockingConnection(connection_parameters)
    channel = connection.channel()
    sync_queue = "sync_queue"
    # Ensure the queue exists
    channel.queue_declare(queue=sync_queue, durable=True)
    send_message(channel=channel, queue_name= sync_queue, message=f"peer{worker_index} completed")
    sync_flag = wait_for_n_messages_or_timeout(channel=channel, queue_name=sync_queue, n= num_worker)
    
    # TODO implement
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
