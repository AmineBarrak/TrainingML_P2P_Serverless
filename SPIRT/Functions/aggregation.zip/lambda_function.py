import redisai
import numpy as np
from sshtunnel import SSHTunnelForwarder
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.backends import default_backend







def get_average_tensor(redis_host, redis_port, key,ec2_ip,SSH_USERNAME,PRIVATE_KEY_PATH,my_port,password):
    # Connect to RedisAI client 
    REDIS_HOST = 'localhost'
    with SSHTunnelForwarder(
    (ec2_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
        r = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= password)

    rai_client = redisai.Client(host=redis_host, port=redis_port)

    # Retrieve tensor from RedisAI
    tensor = rai_client.tensorget(key)

    if tensor:
        tensor_data = tensor.blob
        tensor_array = np.frombuffer(tensor_data, dtype=np.float32)
        tensor_array = np.reshape(tensor_array, tensor.shape)  # Reshape the array according to the tensor shape
        return tensor_array
    else:
        return None


def lambda_handler(event, context):
    # Specify the key to retrieve the values
    input_data = event
    key = 'gradients'
    ec2_ip = input_data['ec2_ip'] 
    my_port = input_data['port']
    password= input_data['password'] 
    SSH_USERNAME = input_data['username'] 
    PRIVATE_KEY_PATH = input_data['path_key']
    REDIS_HOST = 'localhost'
    with SSHTunnelForwarder(
        (ec2_ip, 22),
        ssh_username=SSH_USERNAME,
        ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
        remote_bind_address=(REDIS_HOST, my_port)
        ) as tunnel:
            redis_client  = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= password)
            peers = redis_client.get('trusted_peers')  # Assuming the IP addresses and ports are stored in a Redis list called 'peers'
    
            # Perform aggregation
            average_tensors = []
            
            # Retrieve values from each RedisAI server
        for peer in peers:
            print(peer)
                    """peer_info = peer.decode().split(':')
                    peer_host = peer_info[0]
                    peer_port = int(peer_info[1])
                    tensor = get_average_tensor(peer_host, peer_port, key,ec2_ip,SSH_USERNAME,PRIVATE_KEY_PATH,my_port,password) 
                    average_tensors.append(tensor)"""
                
                # Calculate the average of all tensors
                """if average_tensors:
                    stacked_tensor = np.stack(average_tensors)
                    average_tensor = np.mean(stacked_tensor, axis=0) 
                    rai_client.tensorset(grad_key, average_tensor , shape=average_tensor.shape) 
                
                    # Print the average tensor
                    print("Average Tensor:")
                    print(average_tensor)
                else:
                    print("No values found in any RedisAI server.")"""
                
            