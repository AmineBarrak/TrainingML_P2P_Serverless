import json 
import ModelManager 
import torch.nn as nn
import numpy as np
import torch.nn.init as init 
import redisai as rai 
from sshtunnel import SSHTunnelForwarder
import boto3
import json
import time



def inialize_model(model,redis_client): 
    for m in model.modules():
        if isinstance(m, nn.Conv2d):
            nn.init.kaiming_normal_(m.weight, mode='fan_out', nonlinearity='relu')
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
        elif isinstance(m, nn.BatchNorm2d):
            nn.init.ones_(m.weight)
            nn.init.zeros_(m.bias)
        elif isinstance(m, nn.Linear):
            nn.init.normal_(m.weight, mean=0, std=0.01)
            if m.bias is not None:
                nn.init.constant_(m.bias, 0)
    # Save the parameters in Redis
    save_params_to_redis(model,redis_client)
          
            

def save_params_to_redis(model, rai_client):

    # Collect all parameters of the model into a list
    param_list = [param.data.view(-1).detach().numpy() for param in model.parameters()]
    print('*************************************************************************************************************************')
    print(param_list)  
    print('*************************************************************************************************************************')
    # Concatenate all parameters into a single tensor
    all_params = np.concatenate(param_list) 
    print(all_params) 
    print(len(all_params))
    # Create a unique name for the parameter tensor
    param_key = f'params_small'
    rai_client.tensorset(param_key, all_params, shape=all_params.shape)
def lambda_handler(event, context):
    # TODO implement
  input_data = event
  dataset = input_data['dataset'] 
  model_str= input_data['model_str'] 
  ec2_ip = input_data['ec2_ip'] 
  password= input_data['password'] 
  SSH_USERNAME = input_data['username'] 
  PRIVATE_KEY_PATH = input_data['path_key']
  my_port = input_data['port']
  model =ModelManager.select_model(dataset,model_str)
  REDIS_HOST = 'localhost'
  event['epoch'] = 1
  
  
  
  with SSHTunnelForwarder(
    (ec2_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
        rai_client = rai.Client(host='localhost', port=tunnel.local_bind_port, password= password)
        inialize_model(model, rai_client)
  client = boto3.client('stepfunctions')
  time.sleep(5)
  response = client.start_execution(
    stateMachineArn='arn:aws:states:us-east-1:736943246631:stateMachine:training_workflow',
    input=json.dumps(event)
)
  print("Start Training")
      
