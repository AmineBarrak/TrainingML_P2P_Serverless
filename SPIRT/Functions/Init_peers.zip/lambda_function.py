from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.asymmetric import padding
import redis
from cryptography.hazmat.backends import default_backend
import json
from sshtunnel import SSHTunnelForwarder
import boto3



def encrypt_data(password, publicKey):
    password = password.encode()
    # Encrypt the password using the public key
    encrypted_password = publicKey.encrypt(
        password,
        padding.OAEP(
            mgf=padding.MGF1(algorithm=hashes.SHA256()),
            algorithm=hashes.SHA256(),
            label=None
        )
    )
    return encrypted_password


def generate_private_key():
    private_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048
    )
    private_key_str = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption()
    ).decode('utf-8')
    
    return (private_key,private_key_str)


def generate_public_key(private_key):
    public_key = private_key.public_key()
    pem_public_key = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo
    ).decode()

    public_key_str = pem_public_key
    # Print the public key
    return public_key, public_key_str


def generate_signature(private_key):
    signature = private_key.sign(
        b"OK",
        padding.PSS(
            mgf=padding.MGF1(hashes.SHA256()),
            salt_length=padding.PSS.MAX_LENGTH
        ),
        hashes.SHA256()
    )
    return signature




def lambda_handler(event, context):
    input_data = event
    
    # Perform a calculation using the input data
    SSH_USERNAME = input_data['username']
    PRIVATE_KEY_PATH = input_data['path_key']
    my_ip = input_data['ip_ec2']
    other_sqs_urls = input_data['ips_sns']
    # ports = input_data['ports']
    my_port = int(input_data['my_port'])
    my_password = input_data['password']
    sqs_password = input_data['sns_password']
  
    private_key, private_key_str = generate_private_key()
    my_public_key, public_key_str = generate_public_key(private_key)
    signature = generate_signature(private_key)
    REDIS_HOST = 'localhost'
    with SSHTunnelForwarder(
    (my_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
        r = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= my_password)



        
        r.set('private_key',private_key_str)
        r.set('public_key',public_key_str)
        r.delete('trusted_peers')

    

    # Create an SNS client
    sqs_client = boto3.client('sqs')

    # Sending info to each peer
    info_dict = {'ip': my_ip, 'public_key': public_key_str, 'port': my_port, 'signature': signature, 'sqs_password':sqs_password}
    info_dict['signature'] = info_dict['signature'].decode('latin-1')
    
    notif_new = json.dumps(info_dict)
    
    # Iterate over other_sns_arns and publish the message to each topic
    for sqs_url in other_sqs_urls:
        response = sqs_client.send_message(
            QueueUrl=sqs_url,
            MessageBody=notif_new
        )
    client = boto3.client('lambda', region_name='us-east-1')
    response = client.invoke(
            FunctionName= "arn:aws:lambda:us-east-1:736943246631:function:init_model",
            InvocationType='RequestResponse',  # Synchronous invocation
            Payload= json.dumps(event['init_body'])
            
        )
