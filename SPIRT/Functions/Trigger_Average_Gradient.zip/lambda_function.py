import redis 
import json 
import redisai as rai 
import redis 
import numpy as np 
import boto3 
from sshtunnel import SSHTunnelForwarder
import time
from attacks import sign_flipping,gaussian_attack,gaussian_noise


def lambda_handler(event, context):
  input_data = event

  rank  = input_data['rank'] 
  epoch  = input_data['epoch'] 
  ec2_ip = input_data['ec2_ip'] 
  my_port = input_data['port']
  attack = input_data['attack']

  password= input_data['password'] 
  SSH_USERNAME = input_data['username'] 
  PRIVATE_KEY_PATH = input_data['path_key']
  num_batches = input_data['num_batches'] 
  num_peers = input_data['num_peers'] 
  REDIS_HOST = 'localhost'
  with SSHTunnelForwarder(
    (ec2_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
        r = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= password)
        

        rai_client = rai.Client(host='localhost', port=tunnel.local_bind_port, password= password)


        script = '''
        
        local gradients = redis.call('LRANGE', KEYS[1], 0, ARGV[1] - 1)
        local rank = ARGV[2]  -- Access the rank argument
        
        
        local averageGradient = {}
        for i = 1, #gradients do
            local gradientTensor = cjson.decode(gradients[i])
            if i == 1 then
        
                averageGradient = gradientTensor
            else
        
                for j = 1, #gradientTensor do
                    averageGradient[j] = averageGradient[j] + gradientTensor[j]
                end
            end
        end
        
        for i = 1, #averageGradient do
            averageGradient[i] = averageGradient[i] / #gradients
        end
        
        
        -- redis.call('SET', 'averaged_gradient' .. rank, cjson.encode(averageGradient))
        
        
        return cjson.encode(averageGradient) 
        
        '''
        
        sha = r.script_load(script)
                   # TODO implement



        key = f"gradients_" + str(epoch) 
        grad_key = "averaged_gradient_"+str(epoch)
        sqs = boto3.client('sqs') 
        queue_url = 'https://sqs.us-east-1.amazonaws.com/736943246631/synchronization_mayssa'  
        
        result = r.evalsha(sha, 1, key, num_batches,rank)   
        result_decoded = json.loads(result)
        result_array = np.array(result_decoded, dtype=np.float32) 
        if attack == 'sign_flipping':
            result_array = sign_flipping(result_array,10)
        elif attack == 'gaussian_attack':
            result_array=gaussian_attack(result_array, 100, 0)
        elif attack == 'gaussian_noise':
            result_array=gaussian_noise(result_array, 100, 0)            
            
        rai_client.tensorset(grad_key, result_array, shape=result_array.shape) 
        
        message = {'rank': rank, 'terminated': True}
        sqs.send_message(QueueUrl=queue_url, MessageBody=json.dumps(message))
        while True:
            # Retrieve the number of messages in the SQS queue
            response = sqs.get_queue_attributes(QueueUrl=queue_url, AttributeNames=['ApproximateNumberOfMessages'])
            num_messages = int(response['Attributes']['ApproximateNumberOfMessages']) 
            
            # Check if the number of messages equals the number of peers
            if num_messages == num_peers: 
                  print("pass to aggregation") 
                  break
        time.sleep(5)
        response = sqs.get_queue_attributes(QueueUrl=queue_url, AttributeNames=['ApproximateNumberOfMessages'])
        num_messages = int(response['Attributes']['ApproximateNumberOfMessages']) 
        
        if num_messages > 0 and rank == 0 :
            sqs.purge_queue(QueueUrl=queue_url)
            
        
                   
                
    


