import numpy as np


def no_attack(gradient):
    return gradient



def gaussian_attack(gradient, std_dev, mean):
    gradient = np.random.normal(mean, std_dev, gradient.shape)
    return gradient

def gaussian_noise(gradient, std_dev, mean):
    gradient =+ np.random.normal(mean, std_dev, gradient.shape)
    return gradient

"""def gaussian_noise(gradient,std_dev,mean):
    gradient =+ torch.normal(mean, std_dev, gradient.size())
    return gradient"""

def sign_flipping(gradient, scalar):
    gradient= - gradient * scalar
    return gradient

def label_flipping(targets):
    targets.apply_(lambda x: (9 - x))
    return targets