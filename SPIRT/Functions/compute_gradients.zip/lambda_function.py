import torch 
import ModelManager 
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data as data
import torch.nn.init as init
import boto3 
import numpy as np
import dill as pickle 
import redis 
from sshtunnel import SSHTunnelForwarder 
import redisai as rai 
import json
import time 



def load_data_from_s3(bucket,dataset,rank,model_str,batch_rank):
   s3 = boto3.client('s3')
   folder_name = 'worker4/batch64/'
   worker_key = f'w-{rank}'
   key=f"{folder_name}MNIST-{model_str}_{worker_key}_{batch_rank}.pkl"
   print(key)
   obj = s3.get_object(Bucket=bucket, Key=key)
   data = pickle.loads(obj['Body'].read())
   return data 

class worker(object): 

    
    def __init__(self,bucket,rank,num_workers,base_name,batch_size,batch_rank,dataset,model_str,loss,optimizer,lr,evaluation,compression,print_necessary,sync_total,attack):

        self.rank = rank 
        self.dataset = dataset 
        self.model_str = model_str 
        self.model = ModelManager.select_model(dataset,model_str)
        self.base_name = base_name 
        self.num_workers = num_workers 
        self.batch_size = batch_size 
        self.loss = ModelManager.select_loss(loss)
        self.optimizer = ModelManager.select_optimizer(self.model,optimizer,lr) 
        self.evaluation = evaluation 
        self.compression = compression 
        self.print_necessary = print_necessary 
        self.bucket = bucket 
        self.attack = attack

     
        print('worker has been created')



    def get_params_from_redis(self, con,grad_key):
          # Retrieve the tensor data 
          tensor_data = con.execute_command('AI.TENSORGET', grad_key, 'BLOB')
          # Convert the tensor data to a NumPy array
          params = np.frombuffer(tensor_data, dtype=np.float32) 
          print(params) 
          if params is not None:
 
                with torch.no_grad(): 
                  param_index = 0
                  for param in self.model.parameters():
                       # Get the size of the parameter tensor
                       param_size = param.numel() 
                       # Extract the corresponding portion of the saved_params array
                       param_values = params[param_index:param_index + param_size]
                       # Create a writable copy of the parameter values array
                       param_values = param_values.copy()
                       # Reshape the saved parameters to match the shape of the current parameter tensor
                       param_values = param_values.reshape(param.shape)
                       # Copy the saved parameters to the current parameter tensor
                       param.copy_(torch.from_numpy(param_values))
                       # Increment the parameter index
                       param_index += param_size 
 


    def compute_gradients(self,batch_data):

        #compute the number of batches
        loss_store= []
        dict_peers = {}
        self.model.train()
        data, target = batch_data
        if self.attack == 'label_flipping':
            target = label_flipping(target)
            
        self.optimizer.zero_grad()

        # Forward pass
        output = self.model(data)

        loss_result = self.loss(output,target)

        # Backward pass
        loss_result.backward()
        # Quantize and compress the gradients
        grad = [torch.reshape(p.grad,(-1,)) for p in self.model.parameters()]
        gradients= torch.cat(grad).to("cpu")
        
        return gradients


def lambda_handler(event, context):
  rank = event['rank']
  attack = event['attack']
  batch_rank = event['batch_rank']
  dataset = event['dataset']
  model_str = event['model_str']
  optimiser = event['optimiser']
  optimiser_lr = event['optimiser_lr']
  loss = event['loss'] 
  ec2_ip = event['ec2_ip'] 
  password= event['password'] 
  my_port = event['port']
  size = event['size']
  epoch = event['epoch']
  model =ModelManager.select_model(dataset,model_str)

  

  bucket = "mnist-mobilenet3-small"  
  key = f"gradients_" + str(epoch) 
  # Establish a connection 
  worker_instance = worker(bucket,rank, size, "worker"+str(rank),64,0,"mnist", "mobilenet-v3-small", "cross_entropy","sgd",lr = 0.02,evaluation=True,compression=False,print_necessary=True,sync_total = size,attack=None) 
  redis_host = "172.31.75.179"
  redis_port = 6379
  # Create a Redis client
  r = redis.Redis(host=redis_host, port=redis_port, password="peer4")
  rai_client = rai.Client(host=redis_host, port=redis_port, password="peer4")


  worker_instance.get_params_from_redis( rai_client,"params")
  print('*************************************************************************************************************************')
  param_list = [param.data.view(-1).detach().numpy() for param in  worker_instance.model.parameters()] 
  all_params = np.concatenate(param_list)
  print('param_list*************************************************************************************************************************')
  print( all_params )  
  print('*************************************************************************************************************************')
  data_batch = load_data_from_s3(bucket,dataset,rank,model_str,batch_rank)
  gradients =  worker_instance.compute_gradients(data_batch)
  gradient = gradients.tolist() 
  start_time = time.time()
    
  gradient_json = json.dumps(gradient) 
  r.rpush(key, gradient_json)  
  duration = time.time() - start_time
  r.set('time', duration)
    
          
  return {
            'statusCode': 200,
            'body': json.dumps('Hello from Lambda!')
            }