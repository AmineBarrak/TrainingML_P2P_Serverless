
import torch 
import ModelManager 
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim
import torch.utils.data as data
import boto3 
import numpy as np
import dill as pickle 
import json 
import torch.nn.init as init 
import redisai as rai 
from sshtunnel import SSHTunnelForwarder 
import boto3
import json

def get_data(bucket,model_str,dataset,rank,batch_size):

        data_val = load_data_from_s3(bucket,model_str,dataset,rank)
        valid_set, len_data_partition_val = get_train_set(data_val,batch_size) 
        return valid_set 


def load_data_from_s3(bucket,model_str,dataset,rank):
           s3 = boto3.client('s3') 
           folder_name = 'worker4/dataloader/' 
           worker_key = f'w-{rank}'
           key=f"{folder_name}{dataset}-mobilenet-small_{worker_key}.pkl" 
           print(key)
           obj = s3.get_object(Bucket=bucket, Key=key)
           data_set = pickle.loads(obj['Body'].read())
           train_set_size = int(len(data_set) * 0.9)
           valid_set_size = len(data_set) - train_set_size 
           train_set_data, valid_set_data = data.random_split(data_set, [train_set_size, valid_set_size])
           return valid_set_data 
           
def get_train_set(data_partition,batch_size): 
        
        train_set = torch.utils.data.DataLoader(data_partition, batch_size=batch_size,shuffle=False)
        len_partition = len(data_partition)
        return train_set,len_partition 



def get_params_from_redis(model, con):
          # Retrieve the tensor data 
          tensor_data = con.execute_command('AI.TENSORGET', "my_flattened_tensor", 'BLOB')
          # Convert the tensor data to a NumPy array
          params = np.frombuffer(tensor_data, dtype=np.float32) 
          print(params) 
          if params is not None:
 
                with torch.no_grad(): 
                  param_index = 0
                  for param in model.parameters():
                       # Get the size of the parameter tensor
                       param_size = param.numel() 
                       # Extract the corresponding portion of the saved_params array
                       param_values = params[param_index:param_index + param_size]
                       # Create a writable copy of the parameter values array
                       param_values = param_values.copy()
                       # Reshape the saved parameters to match the shape of the current parameter tensor
                       param_values = param_values.reshape(param.shape)
                       # Copy the saved parameters to the current parameter tensor
                       param.copy_(torch.from_numpy(param_values))
                       # Increment the parameter index
                       param_index += param_size 
                       return model 
                       
                       



           
              
              
def check_convergence(model,loss_fn,valid_set): 


          model.eval()
          loss_total = 0
          counter = 0
          # Test validation data
          with torch.no_grad():
            for inputs,targets in valid_set:
               counter += 1
               outputs = model(inputs)
               loss_result = loss_fn(outputs,targets)
               loss_total += loss_result.item()

            return loss_total / counter 
            
            





def lambda_handler(event, context):
    # TODO implement
  input_data = event
  dataset = input_data['dataset'] 
  model_str= input_data['model_str'] 
  rank = input_data['rank'] 
  batch_size= input_data['batch_size'] 
  bucket =  input_data['bucket'] 
  loss =  input_data['loss'] 
  model =ModelManager.select_model(dataset,model_str) 
  loss_fn = ModelManager.select_loss(loss)
  ec2_ip = input_data['ec2_ip'] 
  password= input_data['password'] 
  SSH_USERNAME = input_data['username'] 
  PRIVATE_KEY_PATH = input_data['path_key']
  my_port = input_data['port']
  epoch = input_data['epoch']
  REDIS_HOST = 'localhost'
  lr= 0.01 
  device = torch.device("cpu:0") 
  best_val_loss = None 
  min_delta = 0 
  counter = 0 
  early_stop = False 
  patience = 10
  epoch = epoch + 1
  client = boto3.client('stepfunctions')


  
  with SSHTunnelForwarder(
    (ec2_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
          rai_client = rai.Client(host='localhost', port=tunnel.local_bind_port, password= password)
          model_result = get_params_from_redis(model,rai_client) 
          valid_set  = get_data(bucket,model_str,dataset,rank,batch_size)  
  val_loss =   check_convergence(model_result,loss_fn,valid_set) 
  if best_val_loss == None:
                    best_val_loss = val_loss
  elif val_loss - best_val_loss < min_delta: 
                    best_val_loss = val_loss
                    # reset counter if validation loss improves
                    counter = 0 
  elif val_loss - best_val_loss >= min_delta:
                    counter += 1
                    print(f"INFO: Early stopping counter {counter} of {patience}")
                    if counter >= patience:
                        print('INFO: Early stopping')
                        early_stop = True 
        




              