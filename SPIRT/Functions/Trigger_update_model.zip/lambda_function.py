import json 
import redis 
import redisai as rai 
from sshtunnel import SSHTunnelForwarder


def update_model(con,lr,grad_key,param_key): 
          con.execute_command('AI.MODELSET', lr, grad_key, 'VALUES', param_key)

           
              
 
            
def lambda_handler(event, context):

 
  input_data = event
  param_key = input_data['param_key']  
  ec2_ip = input_data['ec2_ip'] 
  my_port = input_data['port']
  password= input_data['password'] 
  SSH_USERNAME = input_data['username'] 
  PRIVATE_KEY_PATH = input_data['path_key']
  epoch = input_data['epoch']
  grad_key = "aggregated_gradient_"+str(epoch)
  lr= 0.01 
  REDIS_HOST = 'localhost'
  link = "_link.com"
  with SSHTunnelForwarder(
    (ec2_ip, 22),
    ssh_username=SSH_USERNAME,
    ssh_pkey=PRIVATE_KEY_PATH,  # if using pem file
    remote_bind_address=(REDIS_HOST, my_port)
    ) as tunnel:
      r = redis.Redis(host='localhost', port=tunnel.local_bind_port, password= password)
      r.rpush("link", link) 
        # rai_client = rai.Client(host='localhost', port=tunnel.local_bind_port, password= password)
        # update_model(rai_client ,lr,grad_key,param_key)   

  